kaggle_pbr
==========

My best submission to the Kaggle competition "Predicting a Biological Response", ranked 17th over 711 teams.