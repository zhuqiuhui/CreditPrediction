Demonstrating how to use XGBoost accomplish Multi-Class classification task on [UCI Dermatology dataset](https://archive.ics.uci.edu/ml/datasets/Dermatology)

Make sure you make make xgboost python module in ../../python

1. Run runexp.sh
```bash
./runexp.sh
```


